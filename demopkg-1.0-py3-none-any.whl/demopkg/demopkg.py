def demopkgfun():
    print("Hello this is the demopkfun")